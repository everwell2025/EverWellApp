package com.example.elderlycareapp

data class MemoryCard(
    val imageResId: Int,
    var isFlipped: Boolean = false,
    var isMatched: Boolean = false
)


